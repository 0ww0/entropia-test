(function(win, doc) {

    var $win = $(win);
    var $doc = $(doc);

    @import 'src\assets\script\component\_header.js'
    @import 'src\assets\script\component\_carousel.js'
    @import 'src\assets\script\component\_copyright.js'

})(window, document);
