(function(){

    $('.nav-tabs li.nav-item').on('click', function(e){
        console.log(this);
        // if($('.nav-tabs-indicator li.nav-item-indicator .nav-link-indicator').hasClass('active')){
        //     $('.nav-tabs-indicator li.nav-item-indicator').not('.nav-tabs-indicator li.nav-item').find('.nav-link-indicator').removeClass('active');
        // }

    });

})();
