(function(win, doc) {

    var $win = $(win);
    var $doc = $(doc);

    (function() {
    var  $dataHeaderScroll = 'data-scroll';
    $win.scroll(function(){
        var $this = $(this),
            $topPos = $this.scrollTop(),
            $dataScroll = $('[' + $dataHeaderScroll + ']');

        if($topPos > 80){
            $dataScroll.attr($dataHeaderScroll, 'scroll')
        } else {
            $dataScroll.attr($dataHeaderScroll, '')
        }
    })

})();

    (function() {

    $('.carousel .carousel-item[data-bg-src]').each(function() {
		var $this = $(this);

		$this.prepend([
			'<div class="fe-item-image" style="background-image: url(', $this.attr('data-bg-src'), ')"></div>'
		].join(''));
	});

})();

    (function() {

    var $copyYear = $('.js-copy-years');
    var $year = '2018';
    var $currentYear = new Date().getFullYear();

    if($currentYear > $year){
        $copyYear.html($year + ' - ' + $currentYear);
    } else {
        $copyYear.html($currentYear);
    }

})();

    (function(){

    $('a[href*="#"]')
        .not('[href="#"]')
        .not('[href="#0"]')
        .click(function(event) {
        if ( location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname ){
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
            if (target.length) {
                event.preventDefault();
                $('html, body').animate({
                    scrollTop: target.offset().top - 100
                }, 1000);
            }
        }
    });
    $(window).on('resize', function(e){
        // $dp = ($(window).width() < 1025);
        // $md = ($(window).width() < 801);
        // $sm = ($(window).width() < 641);
        // $xs = ($(window).width() < 481);
    });
})();

    (function(){

    $('#myTab li.nav-item').on('click', function(e){
        $(this).siblings().removeClass('active')
        $(this).addClass('active')
    });

    $('#myTab li.nav-item .nav-link').on('click', function(e){
        $('#myTabIndicator li .nav-link-indicator').not($(this).data('indicator')).removeClass('active')
        $('#myTabIndicator li .nav-link-indicator' + $(this).data('indicator')).addClass('active')
    });

})();


})(window, document);
